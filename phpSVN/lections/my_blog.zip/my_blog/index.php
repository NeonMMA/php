<?php

require_once './vendor/autoload.php';

$base = new MainPage();
$base->display();
