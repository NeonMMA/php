<?php

class MessagePage extends BasePage {
    private $id;
    private $repo;
    function __construct($id)
    {
        parent::__construct("Мастер просмотра сообщений", "тут можно глянуть подробную информаицю", false);
        $this->id = $id;
        $this->repo = new MessageDB();
    }

    function buildContent()
    {
        $message = $this->repo->getById($this->id);
        // array(5) {
        //     ["id"]=>
        //     string(1) "1"
        //     ["owner_id"]=>
        //     string(1) "1"
        //     ["text"]=>
        //     string(19) "text text 1 message"
        //     ["createdAt"]=>
        //     string(19) "2021-12-15 13:15:00"
        //     ["name"]=>
        //     string(6) "Ivanov"
        //   }
          
        // var_dump($message);
        return Template::build(
            file_get_contents('./templates/message-full-card.tpl'),
            $message
        );
    }
}