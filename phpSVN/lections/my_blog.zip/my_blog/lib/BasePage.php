<?php

abstract class BasePage {
    private $header;
    private $description;
    private $showMessageForm;

    abstract public function buildContent();

    function __construct($header, $description, $showMessageForm)
    {
        $this->header = $header;
        $this->description = $description;
        $this->showMessageForm = $showMessageForm ? 1 : 0; // For Template.php
    }

    public function setHeader ($header) {
        $this->header = $header;
    }

    public function setDescription ($description) {
        $this->description = $description;
    }

    public function setShowMessageForm ($value) {
        $this->showMessageForm = $value;
    }

    public function display() {
        $html = implode(
            '',
            [
                $this->buildHeader(),
                $this->buildContentHeader(),
                $this->buildContent(),
                $this->buildFooter()
            ]
        );
        echo $html;
    }

    private function buildHeader() {
        return Template::build(
            file_get_contents('./templates/header.tpl'),
            []
        );
    }

    private function buildFooter() {
        return Template::build(
            file_get_contents('./templates/footer.tpl'),
            []
        );
    }

    private function buildContentHeader() {
        return Template::build(
            file_get_contents('./templates/content-header.tpl'),
            [
                'header' => $this->header,
                'description' => $this->description,
                'showMessageForm' => $this->showMessageForm
            ]
        );
    }
}
