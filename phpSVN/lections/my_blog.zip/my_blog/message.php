<?php

require_once './vendor/autoload.php';

$id = isset($_GET['id']) ? $_GET['id'] : 1;

$base = new MessagePage($id);
$base->display();
